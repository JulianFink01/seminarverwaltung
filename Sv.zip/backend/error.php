<?php

$directory("../");

?>
