<?php


[Database]
host = remotemysql.com:3306
name = UsNSSxycdr
user = UsNSSxycdr
password = NaYCKB35nU

[Mail]
url = https://testURLfindetmaninderIncDatei.html
urlUnterordner = seminarverwaltung/frontend;
[Verwaltung]
username = test
password = test
?>
