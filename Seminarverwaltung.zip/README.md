# seminarverwaltung

Frontend: Julian Hofer, Armin Gross, Felix Welscher
Backend: Simon Mairhofer, Roberth Matha, Benjamin Matscher, Argtim Gashi

Product Owner: Roberth Matha, Julian Fink

For planning and current Project State: -> www.taiga.io
